#include "test.h"

void setup() {

    myClass foo;
    char bar[5] = { 'H', 'e', 'l', 'l', 'o' };
    foo.print('a');
    foo.print("Hello world!");
    foo.print('a', HEX);
    foo.println();

}

void loop() {


}
